
export const API = {
    baseURL : "http://localhost:5000/",
    football : "football/",
    getData : "getData/",
    updateData : "update/",
    deleteData : "delete/",
    getDataByYear: "getdata-by-year/"

}